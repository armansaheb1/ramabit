from django.apps import AppConfig


class AuctionsConfig(AppConfig):
    name = 'auctions'
    class Meta:
        verbose_name = 'سرمایه گذاری'
        verbose_name_plural = 'سرمایه گذاری'